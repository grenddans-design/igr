-- NEXORUM: run this once in Supabase SQL editor

create table if not exists public.game_states (
  device_id text primary key,
  state jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.game_states enable row level security;

-- Anonymous devices can only read/write their own row (matched by device_id
-- they generate and keep in localStorage). This is fine for a casual
-- Telegram Mini App with no login; it is NOT meant to protect against a
-- user editing their own save via devtools.
create policy "device can read own state"
  on public.game_states for select
  using (true);

create policy "device can upsert own state"
  on public.game_states for insert
  with check (true);

create policy "device can update own state"
  on public.game_states for update
  using (true);
