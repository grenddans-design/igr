// === NEXORUM config ===
// 1. Create a project at https://supabase.com
// 2. Run supabase-schema.sql in the SQL editor (Supabase dashboard -> SQL editor)
// 3. Copy your Project URL and anon public key from Project settings -> API
// 4. Paste them below. That's it — no other backend needed.

window.NEXORUM_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-ANON-PUBLIC-KEY",
};
