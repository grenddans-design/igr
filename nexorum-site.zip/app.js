/* ===================== NEXORUM game logic ===================== */

const ICONS = {
  core: "ti-cpu",
  data: "ti-server-2",
  security: "ti-shield-lock",
  vault: "ti-diamond",
  web3: "ti-world",
  satellite: "ti-satellite",
  reactor: "ti-bolt",
  launch: "ti-rocket",
};

const BUILDING_DEFS = [
  { id: "data",     name: "Data center",     color: "c-blue",   icon: ICONS.data,      res: "energy",  baseIncome: 40,  baseCost: 120, unlockLvl: 1 },
  { id: "reactor",  name: "Energy reactor",  color: "c-amber",  icon: ICONS.reactor,   res: "energy",  baseIncome: 60,  baseCost: 180, unlockLvl: 1 },
  { id: "security", name: "Security lab",    color: "c-coral",  icon: ICONS.security,  res: "chips",   baseIncome: 15,  baseCost: 150, unlockLvl: 2 },
  { id: "vault",    name: "Nexo vault",      color: "c-purple", icon: ICONS.vault,     res: "crystal", baseIncome: 10,  baseCost: 200, unlockLvl: 3 },
  { id: "web3",     name: "Web3 hub",        color: "c-teal",   icon: ICONS.web3,      res: "crystal", baseIncome: 12,  baseCost: 260, unlockLvl: 4 },
  { id: "satellite",name: "Satellite",       color: "c-blue",   icon: ICONS.satellite, res: "chips",   baseIncome: 18,  baseCost: 320, unlockLvl: 5 },
  { id: "launch",   name: "Launch center",   color: "c-purple", icon: ICONS.launch,    res: "chips",   baseIncome: 30,  baseCost: 500, unlockLvl: 7 },
];

const MAP_NODES = [
  { id: "ai_city",     name: "AI City",       unlockLvl: 1 },
  { id: "crypto_bank",  name: "Crypto Bank",   unlockLvl: 5 },
  { id: "security_ctr", name: "Security Center", unlockLvl: 8 },
  { id: "launchpad",    name: "Launchpad",     unlockLvl: 10 },
  { id: "space_port",   name: "Space Port",    unlockLvl: 13 },
  { id: "trading_hub",  name: "Trading Hub",   unlockLvl: 16 },
  { id: "nft_gallery",  name: "NFT Gallery",   unlockLvl: 20 },
];

const MISSION_DEFS = {
  daily: [
    { id: "d_collect", name: "Собрать ресурсы", desc: "Соберите ресурсы 1 раз", target: 1, reward: { energy: 100 } },
    { id: "d_upgrade",  name: "Улучшить здание", desc: "Улучшите любое здание 1 раз", target: 1, reward: { energy: 200 } },
    { id: "d_visit",    name: "Зайти в игру",    desc: "Просто зайдите сегодня", target: 1, reward: { crystal: 50 } },
  ],
  weekly: [
    { id: "w_upgrades", name: "5 улучшений", desc: "Улучшите здания 5 раз за неделю", target: 5, reward: { crystal: 300 } },
  ],
  ach: [
    { id: "a_core5",  name: "Ядро 5 уровня",  desc: "Прокачайте AI Core до 5 уровня", target: 5, reward: { chips: 500 } },
    { id: "a_core10", name: "Ядро 10 уровня", desc: "Прокачайте AI Core до 10 уровня", target: 10, reward: { chips: 1500 } },
  ],
};

const SKINS = [
  { id: "default", name: "Ocean Blue",  cls: "",              unlockLvl: 1 },
  { id: "violet",  name: "Violet Core", cls: "skin-violet",   unlockLvl: 3 },
  { id: "crimson", name: "Crimson",     cls: "skin-crimson",  unlockLvl: 6 },
  { id: "toxic",   name: "Toxic Green", cls: "skin-toxic",    unlockLvl: 10 },
  { id: "gold",    name: "Gold Rush",   cls: "skin-gold",     unlockLvl: 15 },
];

const STORY_INTRO = {
  title: "THE FUTURE IS NOT HUMAN",
  text: "В мире на грани краха бывший солдат по имени Горд находит под руинами спящее ядро ИИ. Разбуженное, оно становится его единственным шансом на будущее. Теперь это ядро — ваше. Растите его. Вооружайте. Развивайте — вместе с ним меняется и судьба Горда.",
};

const COMPANION_TIERS = [
  { id: "t1", name: "T-1 ASSIST",   minLvl: 1,  desc: "Базовый юнит поддержки. Создан для помощи и выживания.", img: "assets/companion-t1.png" },
  { id: "t2", name: "T-2 GUARDIAN", minLvl: 3,  desc: "Улучшенная подвижность и защита. Надёжен в бою.", img: "assets/companion-t2.png" },
  { id: "t3", name: "T-3 STRIKER",  minLvl: 6,  desc: "Создан для атаки. Продвинутое оружие. Тактический ИИ активирован.", img: "assets/companion-t3.png" },
  { id: "t4", name: "T-4 TITAN",    minLvl: 10, desc: "Тяжёлая броня. Максимальная огневая мощь. Неудержимая сила.", img: "assets/companion-t4.png" },
  { id: "t5", name: "T-5 NEXORUM",  minLvl: 15, desc: "Больше не металл. Симбиоз достигнут. Будущее — вместе.", img: "assets/companion-t5.png" },
];

function companionTier(level) {
  let cur = COMPANION_TIERS[0];
  for (const t of COMPANION_TIERS) { if (level >= t.minLvl) cur = t; }
  return cur;
}

const DEVICE_KEY = "nexorum_device_id";
const STATE_KEY = "nexorum_state";

function uid() {
  return "d_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function defaultState() {
  const buildings = {};
  BUILDING_DEFS.forEach(b => buildings[b.id] = { level: b.unlockLvl === 1 ? 1 : 0 });
  return {
    commanderLevel: 1,
    core: { level: 1 },
    resources: { energy: 250, crystal: 40, chips: 10 },
    buildings,
    missions: { daily: {}, weekly: {}, ach: {} },
    lastCollect: Date.now(),
    upgradesDoneTotal: 0,
    createdAt: Date.now(),
    storySeen: false,
    lastTierSeen: "t1",
    skin: "default",
    tap: { energy: 1000, max: 1000 },
    dailyRewardClaimedDate: null,
  };
}

function normalizeState(s) {
  if (!s.tap) s.tap = { energy: 1000, max: 1000 };
  if (s.dailyRewardClaimedDate === undefined) s.dailyRewardClaimedDate = null;
  if (!s.skin) s.skin = "default";
  BUILDING_DEFS.forEach(b => { if (!s.buildings[b.id]) s.buildings[b.id] = { level: 0 }; });
  return s;
}

let state = loadLocal() || defaultState();
normalizeState(state);
let deviceId = localStorage.getItem(DEVICE_KEY);
if (!deviceId) {
  deviceId = uid();
  localStorage.setItem(DEVICE_KEY, deviceId);
}

let supa = null;
try {
  const cfg = window.NEXORUM_CONFIG || {};
  if (cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY && !cfg.SUPABASE_URL.includes("YOUR-PROJECT")) {
    supa = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
  }
} catch (e) { console.warn("Supabase init failed", e); }

function loadLocal() {
  try {
    const raw = localStorage.getItem(STATE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function saveLocal() {
  localStorage.setItem(STATE_KEY, JSON.stringify(state));
}

let syncTimer = null;
function scheduleSync() {
  saveLocal();
  setSyncDot("pending");
  clearTimeout(syncTimer);
  syncTimer = setTimeout(syncToSupabase, 1200);
}

async function syncToSupabase() {
  if (!supa) { setSyncDot("local"); return; }
  try {
    const { error } = await supa.from("game_states").upsert({
      device_id: deviceId,
      state,
      updated_at: new Date().toISOString(),
    });
    if (error) throw error;
    setSyncDot("ok");
  } catch (e) {
    console.warn("sync error", e);
    setSyncDot("err");
  }
}

async function loadFromSupabase() {
  if (!supa) { setSyncDot("local"); return; }
  try {
    const { data, error } = await supa
      .from("game_states")
      .select("state")
      .eq("device_id", deviceId)
      .maybeSingle();
    if (error) throw error;
    if (data && data.state) {
      state = data.state;
      normalizeState(state);
      saveLocal();
    } else {
      await syncToSupabase();
    }
    setSyncDot("ok");
  } catch (e) {
    console.warn("load error", e);
    setSyncDot("err");
  }
}

function setSyncDot(mode) {
  const dot = document.getElementById("syncDot");
  const label = document.getElementById("syncLabel");
  dot.classList.remove("ok", "err");
  if (mode === "ok") { dot.classList.add("ok"); label.textContent = "Синхронизировано с Supabase"; }
  else if (mode === "err") { dot.classList.add("err"); label.textContent = "Ошибка синхронизации — сохранено локально"; }
  else if (mode === "pending") { label.textContent = "Сохранение…"; }
  else { label.textContent = "Локальное сохранение (Supabase не настроен)"; }
}

/* ---------- economy helpers ---------- */

function coreIncomePerHour() {
  return Math.round(50 * Math.pow(1.18, state.core.level - 1));
}

function buildingIncomePerHour(def) {
  const lvl = state.buildings[def.id].level;
  if (lvl <= 0) return 0;
  return Math.round(def.baseIncome * lvl * Math.pow(1.12, lvl - 1));
}

function totalIncomePerHour() {
  const totals = { energy: coreIncomePerHour(), crystal: 0, chips: 0 };
  BUILDING_DEFS.forEach(def => {
    totals[def.res] += buildingIncomePerHour(def);
  });
  return totals;
}

function upgradeCost(baseCost, level) {
  return Math.round(baseCost * Math.pow(1.35, level));
}

function coreUpgradeCost() {
  return {
    energy: upgradeCost(500, state.core.level - 1),
    crystal: upgradeCost(150, state.core.level - 1),
    chips: upgradeCost(60, state.core.level - 1),
  };
}

function buildingUpgradeCost(def) {
  const lvl = state.buildings[def.id].level;
  return upgradeCost(def.baseCost, Math.max(lvl, 1) - 1);
}

function canAfford(cost) {
  return Object.entries(cost).every(([res, amt]) => (state.resources[res] || 0) >= amt);
}

function spend(cost) {
  Object.entries(cost).forEach(([res, amt]) => { state.resources[res] -= amt; });
}

/* ---------- offline collect ---------- */

function collectOffline(showToastMsg) {
  const now = Date.now();
  const hours = Math.min((now - state.lastCollect) / 3600000, 12); // cap 12h
  if (hours <= 0) return;
  const rates = totalIncomePerHour();
  Object.entries(rates).forEach(([res, perHour]) => {
    state.resources[res] = (state.resources[res] || 0) + perHour * hours;
  });
  state.lastCollect = now;
  bumpMission("daily", "d_collect", 1);
  if (showToastMsg) showToast("Собрано: +" + Math.round(hours * rates.energy) + " энергии и другие ресурсы");
}

/* ---------- missions ---------- */

function bumpMission(cat, id, amount) {
  const m = state.missions[cat];
  const cur = m[id] || { progress: 0, claimed: false };
  if (cur.claimed) return;
  cur.progress = Math.min((cur.progress || 0) + amount, 999999);
  m[id] = cur;
}

function claimMission(cat, id) {
  const def = MISSION_DEFS[cat].find(m => m.id === id);
  const cur = state.missions[cat][id] || { progress: 0, claimed: false };
  if (cur.claimed || (cur.progress || 0) < def.target) return;
  cur.claimed = true;
  state.missions[cat][id] = cur;
  Object.entries(def.reward).forEach(([res, amt]) => {
    state.resources[res] = (state.resources[res] || 0) + amt;
  });
  showToast("Награда получена: " + rewardText(def.reward));
  render();
  scheduleSync();
}

function rewardText(reward) {
  return Object.entries(reward).map(([res, amt]) => "+" + amt + " " + resLabel(res)).join(", ");
}

function resLabel(res) {
  return { energy: "энергии", crystal: "кристаллов", chips: "чипов" }[res] || res;
}

/* ---------- render ---------- */

let activeScreen = "base";
let activeMissionTab = "daily";
let modalTarget = null; // {type:'core'} or {type:'building', id}

function fmt(n) {
  n = Math.floor(n);
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(2).replace(/\.00$/, "") + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return n.toString();
}

function render() {
  const rates = totalIncomePerHour();
  document.getElementById("resEnergy").textContent = fmt(state.resources.energy);
  document.getElementById("resCrystal").textContent = fmt(state.resources.crystal);
  document.getElementById("resChips").textContent = fmt(state.resources.chips);
  document.getElementById("rateEnergy").textContent = "+" + fmt(rates.energy) + "/h";
  document.getElementById("rateCrystal").textContent = "+" + fmt(rates.crystal) + "/h";
  document.getElementById("rateChips").textContent = "+" + fmt(rates.chips) + "/h";
  document.getElementById("bigEnergyCount").textContent = fmt(state.resources.energy);
  document.getElementById("tapEnergyLabel").textContent = Math.floor(state.tap.energy) + "/" + state.tap.max;
  renderDailyCards();
  document.getElementById("cmdLvl").textContent = "LVL " + state.commanderLevel;
  document.getElementById("coreLvlLabel").textContent = "LVL " + state.core.level;
  const tier = companionTier(state.core.level);
  document.getElementById("coreTierLabel").textContent = tier.name;
  const glyphImg = document.getElementById("coreGlyphImg");
  const glyphIcon = document.querySelector(".core-glyph i");
  glyphImg.src = tier.img;
  glyphImg.classList.add("show");
  glyphIcon.classList.add("hide");
  SKINS.forEach(s => { if (s.cls) glyphImg.classList.remove(s.cls); });
  const activeSkin = SKINS.find(s => s.id === state.skin) || SKINS[0];
  if (activeSkin.cls) glyphImg.classList.add(activeSkin.cls);

  renderBuildings();
  renderMap();
  renderEvolution();
  renderMissions();
  renderAirdrop();
}

function renderBuildings() {
  const grid = document.getElementById("bldGrid");
  grid.innerHTML = "";
  BUILDING_DEFS.forEach(def => {
    const b = state.buildings[def.id];
    const locked = state.core.level < def.unlockLvl && b.level <= 0;
    const el = document.createElement("div");
    el.className = "bld " + def.color + (locked ? " locked" : "");
    el.innerHTML = `
      <i class="ti ${def.icon}"></i>
      <div class="n">${def.name}</div>
      <div class="l">${locked ? "AI Core Lv" + def.unlockLvl : "Ур. " + b.level}</div>
    `;
    if (!locked) el.addEventListener("click", () => openModal({ type: "building", id: def.id }));
    grid.appendChild(el);
  });
}

function renderMap() {
  const grid = document.getElementById("mapGrid");
  grid.innerHTML = "";
  MAP_NODES.forEach(node => {
    const unlocked = state.core.level >= node.unlockLvl;
    const el = document.createElement("div");
    el.className = "node " + (unlocked ? "unlocked" : "locked");
    el.innerHTML = `
      <div class="node-glyph"><i class="ti ${unlocked ? "ti-building-skyscraper" : "ti-lock"}"></i></div>
      <div class="n">${node.name}</div>
      <div class="l">${unlocked ? "Открыто" : "AI Core Lv" + node.unlockLvl}</div>
    `;
    grid.appendChild(el);
  });
}

function renderMissions() {
  document.querySelectorAll("#missionTabs button").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.t === activeMissionTab);
  });
  const list = document.getElementById("missionList");
  list.innerHTML = "";
  MISSION_DEFS[activeMissionTab].forEach(def => {
    const cur = state.missions[activeMissionTab][def.id] || { progress: 0, claimed: false };
    const progress = activeMissionTab === "ach" && def.id === "a_core5" ? state.core.level
      : activeMissionTab === "ach" && def.id === "a_core10" ? state.core.level
      : (cur.progress || 0);
    const done = progress >= def.target;
    const row = document.createElement("div");
    row.className = "row";
    row.innerHTML = `
      <div class="row-icon"><i class="ti ti-target"></i></div>
      <div class="row-body">
        <div class="row-title">${def.name}</div>
        <div class="row-sub">${def.desc} · ${Math.min(progress, def.target)}/${def.target}</div>
      </div>
      <button class="row-action ${cur.claimed ? "done" : ""}" ${cur.claimed ? "disabled" : !done ? "disabled" : ""}>
        ${cur.claimed ? "Готово" : done ? "Забрать" : "Идёт"}
      </button>
    `;
    if (done && !cur.claimed) {
      row.querySelector("button").addEventListener("click", () => claimMission(activeMissionTab, def.id));
    }
    list.appendChild(row);
  });
}

function renderAirdrop() {
  const baseScore = state.core.level * 400;
  const activityScore = Math.min(state.upgradesDoneTotal * 50, 5000);
  const missionsScore = countClaimedMissions() * 120;
  const achScore = countClaimedMissions("ach") * 300;
  const total = baseScore + activityScore + missionsScore + achScore;

  document.getElementById("airdropTotal").textContent = fmt(total);
  const rows = [
    { icon: "ti-building", label: "Уровень базы", val: baseScore },
    { icon: "ti-activity", label: "Активность", val: activityScore },
    { icon: "ti-checklist", label: "Задания", val: missionsScore },
    { icon: "ti-award", label: "Ачивки", val: achScore },
  ];
  const wrap = document.getElementById("airdropRows");
  wrap.innerHTML = "";
  rows.forEach(r => {
    const row = document.createElement("div");
    row.className = "row";
    row.innerHTML = `
      <div class="row-icon"><i class="ti ${r.icon}"></i></div>
      <div class="row-body"><div class="row-title">${r.label}</div></div>
      <div class="row-cost">+${fmt(r.val)}</div>
    `;
    wrap.appendChild(row);
  });
}

function countClaimedMissions(cat) {
  const cats = cat ? [cat] : ["daily", "weekly"];
  let n = 0;
  cats.forEach(c => Object.values(state.missions[c] || {}).forEach(m => { if (m.claimed) n++; }));
  return n;
}

function renderEvolution() {
  const list = document.getElementById("evoList");
  if (!list) return;
  list.innerHTML = "";
  const currentTier = companionTier(state.core.level);
  COMPANION_TIERS.forEach(t => {
    const unlocked = state.core.level >= t.minLvl;
    const isActive = t.id === currentTier.id;
    const card = document.createElement("div");
    card.className = "evo-big-card" + (isActive ? " active" : "") + (!unlocked ? " locked" : "");
    card.innerHTML = `
      <div class="evo-big-figure">
        <img src="${t.img}" alt="${t.name}">
        ${!unlocked ? `<div class="evo-big-lock"><i class="ti ti-lock"></i><span>AI Core Lv${t.minLvl}</span></div>` : ""}
      </div>
      <div class="evo-big-body">
        <div class="evo-big-name">${t.name}</div>
        <div class="evo-big-desc">${t.desc}</div>
        ${isActive ? `<span class="evo-big-tag">ТЕКУЩИЙ</span>` : unlocked ? `<span class="evo-big-tag">ОТКРЫТО</span>` : ""}
      </div>
    `;
    list.appendChild(card);
  });
}

/* ---------- tap-to-earn ---------- */

function tapValue() {
  return Math.max(1, Math.round(coreIncomePerHour() / 400));
}

function onCoreTap() {
  if (state.tap.energy <= 0) {
    showToast("Нет энергии тапа — подождите или используйте Boost");
    return;
  }
  state.tap.energy -= 1;
  state.resources.energy += tapValue();
  danceCore();
  document.getElementById("bigEnergyCount").textContent = fmt(state.resources.energy);
  document.getElementById("resEnergy").textContent = fmt(state.resources.energy);
  document.getElementById("tapEnergyLabel").textContent = Math.floor(state.tap.energy) + "/" + state.tap.max;
  scheduleSync();
}

function boostCost() {
  return Math.round(20 * Math.pow(1.15, state.core.level - 1));
}

function onBoost() {
  const cost = { crystal: boostCost() };
  if (!canAfford(cost)) {
    showToast("Недостаточно кристаллов для Boost (" + fmt(cost.crystal) + ")");
    return;
  }
  spend(cost);
  state.tap.energy = state.tap.max;
  document.getElementById("tapEnergyLabel").textContent = state.tap.max + "/" + state.tap.max;
  showToast("Boost! Энергия тапа заполнена");
  render();
  scheduleSync();
}

/* ---------- daily cards ---------- */

function todayKey() { return new Date().toDateString(); }

function claimDailyReward() {
  if (state.dailyRewardClaimedDate === todayKey()) {
    showToast("Уже забрано сегодня, приходите завтра");
    return;
  }
  state.dailyRewardClaimedDate = todayKey();
  const reward = { energy: 300, crystal: 60 };
  Object.entries(reward).forEach(([r, a]) => { state.resources[r] = (state.resources[r] || 0) + a; });
  showToast("Ежедневная награда: " + rewardText(reward));
  render();
  scheduleSync();
}

function renderDailyCards() {
  const wrap = document.getElementById("dailyCards");
  if (!wrap) return;
  const claimedToday = state.dailyRewardClaimedDate === todayKey();
  wrap.innerHTML = `
    <div class="daily-card ${claimedToday ? "" : "claim"}" id="dcReward">
      ${claimedToday ? "" : `<div class="dc-dot"></div>`}
      <i class="ti ti-gift"></i>
      <div class="dc-name">Награда дня</div>
      <div class="dc-time">${claimedToday ? "Завтра" : "Забрать"}</div>
    </div>
    <div class="daily-card" id="dcMissions">
      <i class="ti ti-checklist"></i>
      <div class="dc-name">Задания</div>
      <div class="dc-time">Перейти</div>
    </div>
    <div class="daily-card soon">
      <i class="ti ti-key"></i>
      <div class="dc-name">Шифр дня</div>
      <div class="dc-time">Скоро</div>
    </div>
    <div class="daily-card soon">
      <i class="ti ti-device-gamepad-2"></i>
      <div class="dc-name">Мини-игра</div>
      <div class="dc-time">Скоро</div>
    </div>
  `;
  document.getElementById("dcReward").addEventListener("click", claimDailyReward);
  document.getElementById("dcMissions").addEventListener("click", () => setScreen("missions"));
}

/* ---------- skins ---------- */

function renderSkinGrid() {
  const grid = document.getElementById("skinGrid");
  grid.innerHTML = "";
  SKINS.forEach(s => {
    const unlocked = state.core.level >= s.unlockLvl;
    const el = document.createElement("div");
    el.className = "skin-swatch" + (state.skin === s.id ? " selected" : "") + (!unlocked ? " locked" : "");
    el.innerHTML = `
      <div class="dot ${s.cls}"><img src="${companionTier(state.core.level).img}"></div>
      <div class="name">${s.name}</div>
      ${!unlocked ? `<div class="req">AI Core Lv${s.unlockLvl}</div>` : ""}
    `;
    if (unlocked) {
      el.addEventListener("click", () => {
        state.skin = s.id;
        scheduleSync();
        render();
        renderSkinGrid();
      });
    }
    grid.appendChild(el);
  });
}

function danceCore() {
  const g = document.querySelector(".core-glyph");
  g.classList.remove("dancing");
  void g.offsetWidth; // restart animation
  g.classList.add("dancing");
}

/* ---------- story / lore ---------- */

function openStory(title, text) {
  document.getElementById("storyTitle").textContent = title;
  document.getElementById("storyBody").textContent = text;
  document.getElementById("storyOverlay").classList.add("open");
}

function closeStory() {
  document.getElementById("storyOverlay").classList.remove("open");
}

function maybeShowIntro() {
  if (!state.storySeen) {
    openStory(STORY_INTRO.title, STORY_INTRO.text);
    state.storySeen = true;
    scheduleSync();
  }
}

function checkTierUp(prevLevel, newLevel) {
  const before = companionTier(prevLevel);
  const after = companionTier(newLevel);
  if (after.id !== before.id) {
    state.lastTierSeen = after.id;
    openStory(after.name, after.desc);
    scheduleSync();
  }
}

/* ---------- modal ---------- */

function openModal(target) {
  modalTarget = target;
  const overlay = document.getElementById("modalOverlay");
  overlay.classList.add("open");
  renderModal();
}

function closeModal() {
  document.getElementById("modalOverlay").classList.remove("open");
  modalTarget = null;
}

function renderModal() {
  if (!modalTarget) return;
  if (modalTarget.type === "core") {
    const lvl = state.core.level;
    const tier = companionTier(lvl);
    const cost = coreUpgradeCost();
    document.getElementById("modalTitle").textContent = tier.name;
    document.getElementById("modalIcon").className = "ti ti-cpu hide";
    const modalImg = document.getElementById("modalIconImg");
    modalImg.src = tier.img;
    modalImg.classList.add("show");
    SKINS.forEach(s => { if (s.cls) modalImg.classList.remove(s.cls); });
    const activeSkin2 = SKINS.find(s => s.id === state.skin) || SKINS[0];
    if (activeSkin2.cls) modalImg.classList.add(activeSkin2.cls);
    document.getElementById("modalLvl").textContent = "Ур. " + lvl;
    document.getElementById("modalRate").textContent = "+" + fmt(coreIncomePerHour()) + " энергии/ч";
    document.getElementById("modalBar").style.width = "60%";
    document.getElementById("modalCost").textContent =
      "Улучшение: " + fmt(cost.energy) + " энергии, " + fmt(cost.crystal) + " кристаллов, " + fmt(cost.chips) + " чипов";
    const loreBtn = document.getElementById("modalLoreBtn");
    loreBtn.style.display = "inline-flex";
    loreBtn.onclick = () => openStory(tier.name, tier.desc);
    const btn = document.getElementById("modalUpgradeBtn");
    btn.disabled = !canAfford(cost);
    btn.onclick = () => {
      if (!canAfford(cost)) return;
      spend(cost);
      const prevLevel = state.core.level;
      state.core.level += 1;
      state.upgradesDoneTotal += 1;
      bumpMission("daily", "d_upgrade", 1);
      bumpMission("weekly", "w_upgrades", 1);
      closeModal();
      render();
      scheduleSync();
      showToast("AI Core улучшен до уровня " + state.core.level);
      checkTierUp(prevLevel, state.core.level);
    };
  } else {
    document.getElementById("modalLoreBtn").style.display = "none";
    document.getElementById("modalIconImg").classList.remove("show");
    const def = BUILDING_DEFS.find(b => b.id === modalTarget.id);
    const b = state.buildings[def.id];
    const cost = buildingUpgradeCost(def);
    const costObj = { [def.res]: cost };
    document.getElementById("modalTitle").textContent = def.name;
    document.getElementById("modalIcon").className = "ti " + def.icon;
    document.getElementById("modalLvl").textContent = "Ур. " + b.level;
    document.getElementById("modalRate").textContent = "+" + fmt(buildingIncomePerHour(def)) + " " + resLabel(def.res) + "/ч";
    document.getElementById("modalBar").style.width = Math.min(20 + b.level * 8, 95) + "%";
    document.getElementById("modalCost").textContent = "Улучшение: " + fmt(cost) + " " + resLabel(def.res);
    const btn = document.getElementById("modalUpgradeBtn");
    btn.disabled = !canAfford(costObj);
    btn.onclick = () => {
      if (!canAfford(costObj)) return;
      spend(costObj);
      b.level += 1;
      state.upgradesDoneTotal += 1;
      bumpMission("daily", "d_upgrade", 1);
      bumpMission("weekly", "w_upgrades", 1);
      closeModal();
      render();
      scheduleSync();
      showToast(def.name + " улучшено до уровня " + b.level);
    };
  }
}

/* ---------- toast ---------- */

let toastTimer = null;
function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 2400);
}

/* ---------- navigation ---------- */

function setScreen(name) {
  activeScreen = name;
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById("screen-" + name).classList.add("active");
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.screen === name));
}

/* ---------- wire up ---------- */

document.querySelectorAll(".nav-btn").forEach(btn => {
  btn.addEventListener("click", () => setScreen(btn.dataset.screen));
});

document.getElementById("coreOpen").addEventListener("click", onCoreTap);
document.getElementById("upgradeCoreBtn").addEventListener("click", () => openModal({ type: "core" }));
document.getElementById("boostBtn").addEventListener("click", onBoost);
document.getElementById("modalClose").addEventListener("click", closeModal);
document.getElementById("modalOverlay").addEventListener("click", e => { if (e.target.id === "modalOverlay") closeModal(); });

document.getElementById("skinsOpenBtn").addEventListener("click", () => {
  renderSkinGrid();
  document.getElementById("skinsOverlay").classList.add("open");
});
document.getElementById("skinsClose").addEventListener("click", () => document.getElementById("skinsOverlay").classList.remove("open"));
document.getElementById("skinsOverlay").addEventListener("click", e => { if (e.target.id === "skinsOverlay") e.currentTarget.classList.remove("open"); });

document.getElementById("storyClose").addEventListener("click", closeStory);
document.getElementById("storyContinueBtn").addEventListener("click", closeStory);
document.getElementById("storyOverlay").addEventListener("click", e => { if (e.target.id === "storyOverlay") closeStory(); });

document.getElementById("collectBtn").addEventListener("click", () => {
  collectOffline(true);
  render();
  scheduleSync();
});

document.querySelectorAll("#missionTabs button").forEach(btn => {
  btn.addEventListener("click", () => { activeMissionTab = btn.dataset.t; renderMissions(); });
});

document.getElementById("learnMoreBtn").addEventListener("click", () => {
  showToast("Правила аирдропа появятся ближе к запуску токена");
});

/* tap energy regen (slow trickle, independent of the 1s resource tick) */
let tapRegenAccum = 0;

bumpMission("daily", "d_visit", 1);

/* passive ticking for live resource counters (visual only, offline collect on Collect click) */
setInterval(() => {
  // live drift so numbers feel alive between collects
  const rates = totalIncomePerHour();
  const dt = 1 / 3600; // 1 second in hours
  Object.entries(rates).forEach(([res, perHour]) => {
    state.resources[res] += perHour * dt;
  });
  document.getElementById("resEnergy").textContent = fmt(state.resources.energy);
  document.getElementById("resCrystal").textContent = fmt(state.resources.crystal);
  document.getElementById("resChips").textContent = fmt(state.resources.chips);
  document.getElementById("bigEnergyCount").textContent = fmt(state.resources.energy);

  // tap-energy regenerates 1 point every 1.5s, up to max
  tapRegenAccum += 1000;
  if (tapRegenAccum >= 1500 && state.tap.energy < state.tap.max) {
    tapRegenAccum = 0;
    state.tap.energy = Math.min(state.tap.max, state.tap.energy + 1);
    document.getElementById("tapEnergyLabel").textContent = Math.floor(state.tap.energy) + "/" + state.tap.max;
  }
}, 1000);

/* periodic autosave */
setInterval(() => { saveLocal(); }, 15000);
window.addEventListener("beforeunload", saveLocal);

/* ---------- init ---------- */

(async function init() {
  setSyncDot("local");
  if (supa) await loadFromSupabase();
  collectOffline(false);
  render();
  maybeShowIntro();
})();
